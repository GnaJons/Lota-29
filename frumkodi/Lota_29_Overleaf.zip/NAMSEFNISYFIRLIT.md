# Námsyfirlit: Lota 29

Útgáfa 1.0 · 10. október 2026 · 10. bekkur

Afhent heild: sjö tímar, 53 ný sýnidæmi, yfirlit, gátlisti og hugtök. Þetta yfirlit skráir unnið efni en fullyrðir ekki um forþekkingu sem hefur verið staðfest í eldri lotum.

## Tímar, forþekking og stöðug auðkenni

| Tími | Kennt efni og ný hugtök | Nauðsynleg forþekking | Sýnidæmi | Auðkenni |
|---|---|---|---|---|
| 1 | Ferstrendingur, teningur, snið, rúmmál, yfirborð, eðlismassi, stærðarhlutfall | Margföldun, veldi, rétthyrningsflatarmál, einingar og hlutföll | 1.1–1.6 | timi:lota29-01 |
| 2 | Strendingur, grunnflötur, hornrétt hæð, möttull, þversnið, trapisa; samsett flatarmál | 1. tími, þríhyrningsflatarmál og Pýþagóras | 2.1–2.7 | timi:lota29-02 |
| 3 | Sívalningur, radíus, þvermál, ummál, möttull, þunnt lag | 1.–2. tími, hringflatarmál, einingabreytingar | 3.1–3.6 | timi:lota29-03 |
| 4 | Strýta, pýramídi, keila, skáhlið, samsett rúmmál, efri mörk efnisnýtingar | Grunnflatarmál, Pýþagóras, rúmeiningar | 4.1–4.8 | timi:lota29-04 |
| 5 | Kúla, hálfkúla, bogið yfirborð, endurmótun, massahlutfall | Veldi, hlutföll, prósentur, eðlismassi | 5.1–5.7 | timi:lota29-05 |
| 6 | Samsett form, hálfsívalningur, einangrun hæðar, prósentubreytingar | 1.–5. tími og einfaldar jöfnur | 6.1–6.9 | timi:lota29-06 |
| 7 | Rúmmálshlutföll, óþekktur radíus, hæð hliðarflatar, hornalína í kassa, ytra yfirborð | Fyrri tímar, ferningsrætur og Pýþagóras | 7.1–7.10 | timi:lota29-07 |

Sameiginleg auðkenni: `yfirlit`, `gatlisti`, `hugtok`. Hugtök nota stöðuga lykla `hugtak:<heiti>` í frumkóðanum. Í hverri færslu eru tenglar aftur í viðeigandi tíma. Ekkert nemendaefni kemur á eftir hugtakakaflanum.

## Kortlagning allra verkefna og undirliða

Númerin 29.1–29.65 vísa í verkefnablöð kennarans. Númerin 1.1–7.10 vísa í nýju sýnidæmin. Tölur í sýnidæmum eru ekki svör við verkefnunum.

| Verkefni | Færni sem þarf að kenna | Stuðningur í leshefti |
|---|---|---|
| 29.1 a–b | Ferstrendingsrúmmál úr cm og mm; lítrar | 1.1 |
| 29.2 | Rúmmál margfaldað með gefnum eðlismassa | 1.4 |
| 29.3 a–b | Sex rétthyrndir fletir, tugabrot | 1.2 |
| 29.4 | Lokaður kassi með loki; mm yfir í m² | 1.2 |
| 29.5 | Lágmarksumbúðaefni á hvern kassa, án skörunar | 1.2 |
| 29.6 a–b | Lesa snið; rúmmál og yfirborð tenings | 1.3 og TikZ-snið |
| 29.7 | Rúmmál jafndjúps geymis og magn í gefnu hlutfalli | 1.5 |
| 29.8 a–c | Hlutfall k³, k², magn og kostnaður smærri kassa | 1.6 |
| 29.9 | Tvær mismunandi hæðir í þrístrendingi | 2.1 og TikZ-mynd |
| 29.10 a–b | Þríhyrningsgrunnur með hæð eða réttu horni | 2.1, 2.3 |
| 29.11 a–c | Rúmmál, lítrar, Pýþagóras, ummál, möttull, tveir endar | 2.3 og útbreiddur möttull |
| 29.12 a–b | Gefið grunnflatarmál sinnum strendingshæð | 2.2 |
| 29.13 | Þrep skipt í rétthyrninga, síðan margfaldað með breidd | 2.4 og þrepaþversnið |
| 29.14 | Trapisuflatarmál úr samsíða breiddum og dýpt | 2.5 |
| 29.15 | Rétthyrningur og þríhyrningur; heildarhæð mínus vegghæð | 2.6 |
| 29.16 a–d | Skissa, rúmmál, skáhlið botns, langveggir og endaveggir | 2.7 og merkt langsnið |
| 29.17 a–b | Standandi og liggjandi sívalningur; radíus eða þvermál | 3.1–3.2 |
| 29.18 a–b | Sívalningsrúmmál í cm³ og lítrum | 3.1–3.2 |
| 29.19 | Innanmál sívalnings og lítrar | 3.1–3.2 |
| 29.20 | Liggjandi tankur, þvermál og lengd í m, lítrar | 3.2 |
| 29.21 | Möttull úr þvermáli og hæð | Regla og mynd fyrir 3.3; 6.2 |
| 29.22 | Möttull margfaldaður með fjölda og cm² yfir í m² | 3.3 |
| 29.23 a–c | Samtals möttull, þekja málningar, heil dósakaup og kostnaður | 3.4 |
| 29.24 a–b | Þunnt lag, mm yfir í m, rúmmetrar og lítrar | 3.5 |
| 29.25 a–b | Plötubreidd verður ummál; einangra radíus og reikna rúmmál | 3.6 og TikZ-skýring |
| 29.26 a–c | Rétthyrndur, ferningslaga og þríhyrndur grunnur pýramída | 4.1–4.2 |
| 29.27 a–b | Ferningur í grunni og hornrétt hæð | 4.1 |
| 29.28 | Hæð grunnþríhyrnings aðgreind frá hæð pýramída | 4.2 |
| 29.29 a–c | Keilurúmmál úr radíus eða þvermáli | 4.3–4.4 og keilumynd |
| 29.30 | Keilulaga bingur, cm yfir í m áður en rúmmál er fundið | 4.4 |
| 29.31 a–b | Radíus og skáhlið í möttulsformúlu | 4.5 |
| 29.32 | Möttull margfaldaður með fjölda, án grunnhrings | 4.5 |
| 29.33 | Varðveisla rúmmáls, lengd veggjar úr þversniðsflatarmáli | 4.6 |
| 29.34 | Keiluílát, þvermál, cm³ yfir í cℓ | 4.4 |
| 29.35 | Rúmmál sívalnings og keilu lagt saman, m³ yfir í lítra | 4.7 og mynd |
| 29.36 | Skáhlið úr Pýþagórasi, möttull, fjöldi heilla forma og fyrirvari um afskurð | 4.8 |
| 29.37 a–d | Rúmmál kúlu úr radíus; cm, dm, m og tugabrot | 5.1–5.2; einingaregla 1. tíma |
| 29.38 a–d | Helminga þvermál áður en radíus er hafinn í þriðja veldi | 5.2 |
| 29.39 a–b | Kúluskissa og rúmmál í lítrum | 5.2 og kúluteikning |
| 29.40 | Innanþvermál hálfkúlu og hálft kúlurúmmál | 5.3 |
| 29.41 | Yfirborð kúlu úr radíus | 5.4 |
| 29.42 | Yfirborð úr stóru þvermáli í km | 5.4, ímyndað tungl |
| 29.43 | Efni utan um kúlu, flatarmál | 5.4 |
| 29.44 | Endurmótun kúlu, samræmdar cm/mm einingar og fjöldi | 5.6 |
| 29.45 | Rúmmál beggja kúlna og mismunandi eðlismassi | 5.7 |
| 29.46 | Bogið hálfkúluyfirborð og prósentuviðbót | 5.5 |
| 29.47 a–f | Velja formúlur sex rúmhluta og lesa rétt horn, radíus, þvermál | 6.1; myndir og aðferðir fyrri tíma |
| 29.48 a–b | Yfirborð tenings og möttull sívalnings | 6.2 |
| 29.49 a–b | Hálfur sívalningur, rúmmál og dúkur með tveimur endum | 6.3 og skýlismynd |
| 29.50 | Sívalningur og hálfkúla, aðgreindar hæðir | 6.4 |
| 29.51 | Hækkun vatnsborðs úr viðbótarrúmmáli | 6.5 |
| 29.52 a–b | Hæð úr tveimur rúmtökum, cℓ yfir í cm³ | 6.6 |
| 29.53 | Einangra hæð pýramída, stuðullinn 3 | 6.7 |
| 29.54 | Ummál í radíus og síðan rúmmál | 6.8 |
| 29.55 a–b | Lengdarprósenta í k, síðan k²−1 og k³−1 | 6.9 |
| 29.56 | Rúmmálshlutfall einslaga teninga | 7.1 |
| 29.57 a–b | Pýþagóras fyrir radíus keilu og þvermál sívalnings | 7.4–7.5, tveir réttir þríhyrningar |
| 29.58 | Hæð þríhyrnds hliðarflatar úr hliðarbrún; fjórir hliðarfletir og grunnur | 7.6 og mynd hliðarflatar |
| 29.59 | Grunnbrúnir háðar x; setja upp og leysa x²-jöfnu | 7.7 |
| 29.60 a–b | Rúmmál tenings úr grunnflatarmáli eða heildaryfirborði | 7.8 |
| 29.61 a–b | Bera saman r²h fyrir tvo sívalninga og stytta rúmmálshlutfall | 7.2 |
| 29.62 | Radíus úr rúmmáli og hæð; jákvæð ferningsrót | 7.3 |
| 29.63 a–b | Hornalína botns og hornalína í kassa með Pýþagórasi tvisvar | 7.9 og rúmmynd |
| 29.64 | Lengsta beina stöng innan kassa | 7.9 |
| 29.65 | Óþekktur radíus, keilumöttull og bogin hálfkúla; sleppa innri grunnhring | 7.10 og samsett mynd |

## Sýnidæmasafn til áframhaldsvinnu

- **1. tími:** geymslukassar 48 × 25 × 32 cm og 620 × 450 × 800 mm; yfirborð með 4,2/3,1/2,6 cm og 640/300/280 mm; teningur 3,5 cm; steinn 12 × 7 × 4 cm með 2,5 g/cm³; vatnsgeymir 18 × 7 × 1,6 m; gjafakassar með k = 1/3.
- **2. tími:** grunnþríhyrningur b = 6, g = 4 og strendingshæð 9 m; G = 46 eða 73 cm² og h = 18 cm; rétthyrndur grunnur 1,5/2/2,5 m og lengd 3,2 m; þrep 0,42/0,28/0,18 m; rás 1,8/0,8/1,1 m og lengd 14 m; hús 8/3/5,5/14 m; laug með láréttu köflunum 4/10/6 m, dýptum 0,9/2,4 m og breidd 9 m.
- **3. tími:** ílát r = 4,5 og h = 18 cm; tankur d = 1,1 og L = 2,6 m; 1800 borðar r = 2,8 og h = 9,4 cm; sex stólpar d = 0,5 og h = 3 m; vatnslag r = 18 m, þykkt 0,8 mm; plastplata 24 × 84 cm.
- **4. tími:** ferningspýramídi 16/21 cm; rétthyrndur pýramídi 18/10/14 cm; þríhyrndur grunnur 9/4 dm og h = 15 dm; keila 7/24/25 cm; sandbingur d = 5 og h = 1,8 m; mæliílát d = 6 og h = 8 cm; skrautkeilur r = 3,6 og s = 8,5 cm; pýramídaefni 12/9 m í vegg 0,6/1,2 m; hylki d = 1,2 með hæðum 1,4/0,5 m; skrautkeila d = 8 og h = 15 cm úr 50 × 90 cm efni.
- **5. tími:** kúla r = 4 cm; belgur d = 0,9 m; hálfkúlutjald d = 3,6 m; lampaskermur r = 22 cm; ímyndað tungl d = 2600 km; þak d = 7,6 m með 12% viðbót; vaxkúla 6 cm í 3 mm kúlur; efni A/B með þvermál 1,6/2,4 cm og eðlismassa 7,5/2,4 g/cm³.
- **6. tími:** sex form með nýjum mæligildum; teningur 3,2 cm og sívalningsmöttull d = 18, h = 7 cm; skýli L = 12 og d = 5 m; turnlíkan r = 3 og sívalningshæð 7 cm; vatnsborðshækkun með d = 1,6 m og 2,4 m³; ílát d = 7 cm, 42 og 70 cℓ; pýramídi a = 9 cm, R = 405 cm³; ummál 31,4 cm og h = 7 cm; 15% lengdaraukning.
- **7. tími:** teningsbrúnir 9/6 cm; sívalningar r/h = 3/20 og 5/12 cm; 0,75 lítra ílát h = 16 cm; keila h/s = 40/41 cm; ásþversnið sívalnings með h/hornalínu = 24/25 cm; ferningspýramídi með grunnbrún/hliðarbrún = 20/26 cm; grunnbrúnir x/3x, h = 10 cm, R = 1470 cm³; teningsflatarmál G = 81 og Y = 864 cm²; kassamál 12/9/20 cm; keila á hálfkúlu með h/s = 12/13 cm.
