# Kennaranóta: Lota 29

Útgáfa 1.0 · 10. október 2026 · 10. bekkur

Heftið kennir færnina í öllum sjö afhentum verkefnablöðunum. Öll 53 sýnidæmin eru ný: tölusamsetningar og aðstæður eru aðrar en í verkefnunum. Endurtekin grunnheiti, formúlur eða einstakar tölur jafngilda ekki endurnotkun verkefnadæmis. Ekkert verkefnadæmanna er birt með lausn í nemendaheftinu.

## Gögn og afmörkun

- Lesin voru verkefnablöðin `29.1 dæmi.pdf` til `29.7 dæmi.pdf` úr möppunni Lota 29, samtals 13 PDF-síður. Allar síðurnar voru skoðaðar sem myndir, auk textaútdráttar.
- Lausnaskrár og lotupróf í sömu möppu voru ekki notuð.
- Tímaskiptingin er tekin af fyrirsögnum verkefnablaðanna. Bekkurinn er staðfestur af möppusamhengi sem kennari afhenti.
- Stíll og uppbygging fylgja `lota27-approved.tex`, leiðbeiningunum í viðbótinni og sjónrænni fyrirmynd á fyrstu síðu `lesefni-lota-14.pdf`. Það PDF var aðeins notað sem útlitsfyrirmynd.
- Nemendaheftið er sjálfstæð LaTeX-skrá: 12 pt Latin Modern, Letter, 20 mm spássíur, pdfLaTeX og TikZ. Engar ytri myndaskrár þarf.
- Tákn fylgja verkefnunum: R fyrir rúmmál og M fyrir möttul. G táknar grunnflatarmál, Y yfirborðsflatarmál og U ummál.
- Hugtökin eru byggð á orðalagi verkefnanna og hefðbundnum stærðfræðihugtökum. Sérstakt samþykkt hugtakasafn kennarans fylgdi ekki. „Ferstrendingur“ er skýrt afmarkað við rétthyrndan ferstrending í þessu hefti; reglum um möttul er beitt á rétta strendinga og rétta hringkeilu.

## Myndháð atriði og forsendur verkefnablaðanna

Þetta eru athugasemdir fyrir kennara, ekki lausnalykill. Upprunalegum PDF-skjölum var ekki breytt.

1. **29.6:** Sniðið sýnir sex ferninga með 24,5 cm hlið. Brúnarlengd fæst úr mynd, ekki úr megintexta. Nýtt sýnidæmi 1.3 notar annað netmál og kennir bæði rúmmál og yfirborð.
2. **29.10 a–b:** Í a er 4,2 dm hornrétt hæð á 6,0 dm grunnlínu; hæð strendings er 7,5 dm. Í b mynda 2,4 cm og 3,2 cm rétta hornið í grunnþríhyrningi; strendingshæðin er 8,0 cm. Þessi tvö hæðarhugtök eru aðgreind í 2.1–2.3.
3. **29.11 c:** Orðalagið „efni í hliðarnar“ getur verið þrengra en viðbótin „lokaður í báða enda“. Eðlileg túlkun í samhengi er allt yfirborðið, M + 2G. Lesheftið greinir möttul og heildaryfirborð með skýrum heitum.
4. **29.13:** Þrepamyndin sýnir tvær 16 cm hækkanir, 45 cm efri þreplengd, 25 cm viðbótarþreplengd og 120 cm breidd. Dæmi 2.4 kennir skiptingu í tvo rétthyrninga án tvítalningar.
5. **29.14:** Efri breidd skurðarins er þrír 0,50 m kaflar; neðri breidd samsvarar miðkaflanum. Hornrétt dýpt er 1,20 m og lengd 12 m. Nýtt dæmi gefur báðar samsíða breiddir beint.
6. **29.15:** Heildarhæð húss er 6,4 m en vegghæð 2,8 m. Þakhæð verður að fást með frádrætti; 6,4 m er ekki hæð þríhyrningsins eins og sér. Grunnbreidd er 9,5 m og lengd 16,2 m.
7. **29.16:** Gefið er 24,8 m heildarlengd, 6,0 m og 11,0 m láréttir botnhlutar og „8,0 m langur halli“, með 1,8 m dýptarmun. Ef 8,0 m er lárétt lengd verður summan 25,0 m, ekki 24,8 m. Ef 8,0 m er lengd eftir hallanum verður lárétti kaflinn sqrt(8² − 1,8²), og heildin um 24,795 m, sem námundast í 24,8 m. Síðari túlkunin getur því samræmst gögnunum. Kennari þarf að skýra mæliaðferð og námundun. Í sýnidæmi 2.7 eru láréttar lengdir skýrt gefnar og samræmast heildarlengd nákvæmlega; lengdin eftir hallanum er reiknuð sérstaklega.
8. **29.17:** Í a er 11 cm radíus, ekki þvermál. Í b er 20 cm þvermál og 35 cm lengd sívalningsins. **29.20:** Tankmyndin gefur 0,94 m þvermál og 2,3 m lengd; innanmál eru sérstaklega tilgreind í texta.
9. **29.23:** Málningarmagn er fyrst samfellt lítramagn; fjöldi eins lítra dósa er síðan hækkaður upp í heila tölu. Nýtt dæmi gerir ráð fyrir einni umferð og gefinni þekju.
10. **29.25:** Styttri plötuhlið verður hæð og lengri hlið ummál. Gert er ráð fyrir engri skörun og hverfandi efnisþykkt. Plata ein sér myndar opinn möttul, ekki lokað ílát; sýnidæmið orðar því rúmmálið sem afmarkað rými.
11. **29.26:** a sýnir rétthyrndan grunn 32 × 16 dm og hornrétta hæð 18 dm; b sýnir ferningsgrunn með hlið 11 m og 21 m hæðarmerkingu. Í c er grunnflöturinn þríhyrningur: 7,5 cm grunnbrún, 8,0 cm hornrétt hæð í grunnþríhyrningi og 9,0 cm hæð pýramídans. Stækkuð mynd var skoðuð til að greina þessi atriði.
12. **29.29:** a og b gefa radíus (12 dm og 10 m); c gefur 26 cm þvermál. **29.31 a:** 74 cm er skáhlið og 24 cm radíus. **29.31 b:** myndin aðgreinir hæð 28 cm, radíus 45 cm og skáhlið 53 cm.
13. **29.33:** Sögulegar stærðarupplýsingar um raunverulegan pýramída eru ekki teknar yfir sem sannreyndar staðreyndir. Nýja dæmið er skýrt reiknilíkan um efnismagn, án holrúma eða taps.
14. **29.35:** 0,80 m er sameiginlegt þvermál, 0,75 m hæð sívalnings og 0,40 m hæð keilu. Engin lengd útrennslisstúts er gefin; í námsnálguninni er hann ekki hluti reiknaðs rúmmáls.
15. **29.36:** Þvermál og hornrétt hæð gefa ekki skáhlið beint. Hún þarf að fást með Pýþagórasi áður en möttull er reiknaður. Flatarmál deigs deilt með flatarmáli eins forms gefur aðeins efri mörk fyrir fjölda heilla forma. Það tryggir ekki að snið raðist á rétthyrnda plötuna án afskurðar. Þetta er skýrt í 4.8.
16. **29.40 og 29.46:** Rúmmál hálfkúlu er helmingur rúmmáls kúlu. Við þakklæðningu er aðeins bogna yfirborðið talið með, ekki flati grunnhringurinn.
17. **29.44–45:** Við bræðslu er gert ráð fyrir varðveislu efnis og engum rúmmálsbreytingum. Við samanburð massa þarf bæði rúmmál og gefinn eðlismassa. Nýju dæmin nota vax og skýrt skilgreind efni A og B.
18. **29.47:** Myndir sýna a ferstrending (135, 240, 74 mm), b ferningspýramída (grunnbrún 25 dm og hæð 27 dm), c þrístrending með rétthyrndan grunn (8 og 12 cm, strendingshæð 10 cm), d keilu (þvermál 32 m og hæð 42 m), e sívalning (radíus 0,80 m og hæð 1,20 m), f kúlu (radíus 35 cm).
19. **29.49:** Ekki er nákvæmlega sagt hvort plast sé á endum eða hvort dyr séu dregnar frá. Nýja dæmið 6.3 gerir forsendurnar sýnilegar: báðir endar lokaðir, enginn gólfdúkur, engin dyraop dregin frá.
20. **29.50:** 40 m eru samkvæmt textanum hæð sívalningsins, ekki heildarhæð með hálfkúlu. Nýtt dæmi notar líkansturn og greinir sérstaklega hæð hlutanna. Staðhæfingar um raunverulegu stjörnuathugunarstöðina voru ekki sannreyndar eða notaðar.
21. **29.51–52:** Vatnsborðshækkun og hæð íláts krefjast innanmála. Gert er ráð fyrir stöðugum grunnfleti og engu leka eða yfirfalli. Sentilítrar eru samræmdir við cm³ áður en jafnan er leyst.
22. **29.55–56:** Reglur um k² og k³ krefjast þess að allar samsvarandi lengdir breytist í sama hlutfalli. **29.61:** Dósirnar hafa hins vegar ólíkt hlutfall radíus- og hæðarbreytingar; reikna þarf r²h fyrir hvora.
23. **29.57:** a gefur hornrétta hæð 56 cm og skáhlið 65 cm. Í b gefur 17 cm hornalína ásþversniðs ásamt hæð 15 cm þvermál sívalnings, ekki radíus. Þessu er sérstaklega sinnt í 7.4 og 7.5.
24. **29.58:** 40 cm merkingin er á hliðarbrún frá toppi í grunnhorn; hún er ekki merkt hæð hliðarflatarins. Grunnbrúnin er 36 cm og helmingur hennar 18 cm. Myndin er túlkuð sem reglulegur ferningspýramídi með fjóra eins hliðarfleti. Án þeirrar samhverfuforsendu er heildaryfirborðið ekki ákvarðað af þessum lengdum einum. Dæmi 7.6 segir forsenduna skýrt og finnur hæð hliðarflatar með Pýþagórasi.
25. **29.63–64:** AC er hornalína botns en AD hornalína í kassa. Lengsta beina stöngin er líkan án þykktar og málað er með innanmálum. 7.9 kennir bæði skrefin og almennu regluna.
26. **29.65:** Keila og hálfkúla deila grunnhring. Hæð keilunnar er 11,0 cm og skáhlið 14,6 cm; radíus er óþekktur. Við ytra yfirborð leggjast saman keilumöttull og boginn hálfkúluflötur; sameiginlegur hringur telst ekki með.

## Prófun og afhending

- Útreikningar allra 53 sýnidæmanna voru endurreiknaðir; 92 sérstakar athuganir náðu yfir gildi, einingabreytingar, námundun, hlutföll og heiltölufjölda.
- PDF var þýtt með staðbundnum pdfLaTeX (MiKTeX), og þýtt aftur til að uppfæra tengla og sjálfvirkar síðutilvísanir. Innbyggða forsýningarþýðingin rakst á aðgangsvillu áður en LaTeX-kóðinn var keyrður; sú villa var ekki kóðavilla. Sjálfstæða .tex-skráin var send til opnunar í innbyggða ritlinum.
- Sjónræn yfirferð tók til síðuskiptingar, mynda, merkimiða, dæmaboxa, yfirlits, gátlista og hugtaka. Stuttar framhaldssíður voru lagfærðar og hæðarmerking þrístrendings færð að réttri hliðarbrún.
- Lokaútgáfan er 31 síða. Síðasta pdfLaTeX-keyrsla skilaði engum viðvörunum um yfirflæði, gisnar línur eða óuppfærðar tilvísanir. Lengdarmerkingar á keilu, ásþversniði og samsettum hlut voru færðar svo þær lægju ekki ofan á teiknuðum línum.
- Sjálfstæði frumkóðinn er `Lota_29_leshefti.tex`. Í Overleaf-ZIP heitir nákvæmlega sama skrá `main.tex`. Kennaranóta og námsyfirlit eru utan nemendaheftisins.
- Engin bein upphleðsla í Overleaf var framkvæmd. ZIP-skráin er tilbúin til innflutnings með pdfLaTeX.
